from django.test import SimpleTestCase
from django.urls import reverse, resolve

from budget.views import project_list, project_detail, ProjectCreateView

class TestUrls(SimpleTestCase):
    
    def test_list_url(self):
        #assert 1 == 1
        url = reverse('list')
        #print(f"\nResorved url function returned object:{resolve(url).func}\n")
        #print(f"\nView function  returned object: {project_list}")
        self.assertEquals(resolve(url).func, project_list)
        """
        Note that the two objects have the same type so we can also use assert == or assertIS

        assert with operators -----> assert <object> == <object>: 
            assert resolve(url).func == project_list 
            ----> just like assertEquals, The two objects need not to have the same type

        assertIS:
            self.assertIs(resolve(url).func, project_list)
            but note that the two objects must have the same type
        """

    def test_add_url(self):
        url = reverse('add')
        # Here we put func.view_class to indicate that we are dealing with a class based view
        # self.assertEquals(resolve(url).func.view_class, ProjectCreateView)
        self.assertIs(resolve(url).func.view_class, ProjectCreateView)
       


    def test_details_url(self):
      
        url = reverse('detail', args=['some-slug'])
        #print(resolve(url))
        # Here we put only resolve(url).func to indicate that we are dealing with a function based view
        #self.assertEquals(resolve(url).func, project_detail)
        assert resolve(url).func == project_detail 
        
