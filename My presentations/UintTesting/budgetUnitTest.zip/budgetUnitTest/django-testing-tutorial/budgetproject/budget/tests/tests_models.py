from django.test import TestCase

from budget.models import Category, Expense, Project

class TestModel(TestCase):

    def setUp(self) :
        self.my_project = Project.objects.create(
            name = 'Project1',
            budget = 9000
        )


    
    def test_bduget_left(self):
        category1 = Category.objects.create(
            name = 'programming',
            project= self.my_project
        ) 


        expense1 = Expense.objects.create(
            project= self.my_project,
            title = 'Any thing',
            amount = 700,
            category = category1
        )

        self.assertEquals(self.my_project.budget_left, 8300)
     
  

    def test_project_is_assigned_slug(self):
        print(self.my_project.slug)
        self.assertEquals(self.my_project.slug, 'project1')



    @property
    def budget_left(self):
        expense_list = Expense.objects.filter(project=self)
        total_expense_amount = 0
        for expense in expense_list:
            total_expense_amount += expense.amount

        total_expense_amount = int(total_expense_amount)

        return self.budget - total_expense_amount
