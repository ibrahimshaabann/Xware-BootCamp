# Import necessary modules and classes
from django.test import TestCase, Client
from django.urls import reverse
from budget.models import Category, Project, Expense

# Create a test class to test views
class TestViews(TestCase):

    def setUp(self):
        """
        Set up the initial state for each test.

        This method is called before each test case is executed.
        """
        self.client = Client() # Create an instance of the Django test client for making HTTP requests.
        self.list_url = reverse('list')  # Get the URL for the project list view
        self.MyProject = Project.objects.create(
            name='MyProject',
            budget=5000
        )
        self.detail_url = reverse('detail', args=[self.MyProject.slug])  # Get the URL for the project detail view using the project's slug
        self.add_post_url = reverse('add')

    def test_project_list_GET(self):
        """
        Test for the project list view (GET request).

        Sends a GET request to the project list view and asserts that the response
        status code is 200 (OK) and that the 'project-list.html' template is used
        to render the respons
        e.
        """
        response = self.client.get(self.list_url) # Use the client to make a GET request to a specific URL
        self.assertEquals(response.status_code, 200)
        self.assertTemplateNotUsed(response, 'project-list.html')

    def test_project_detail_GET(self):
        """
        Test for the project detail view (GET request).

        Sends a GET request to the project detail view and asserts that the response
        status code is 200 (OK) and that the 'project-detail.html' template is used
        to render the response.
        """
        response = self.client.get(self.detail_url)
        self.assertEquals(response.status_code, 200)
        self.assertTemplateUsed(response, 'project-detail.html')

    def test_project_detail_POST_add_new_expense(self):
        """
        Test for adding a new expense to a project (POST request).

        Creates a category for the project, sends a POST request to add a new expense,
        and then asserts that the first expense of the project has the title 'Expense 1'.
        """
        Category.objects.create(
            project=self.MyProject,
            name='development'
        )
        response = self.client.post(self.detail_url,
                                   {
                                       'title': 'Expense 1',
                                       'amount': 100.00,
                                       'category': 'development',  # Specify the category name
                                   })
        self.assertEquals(self.MyProject.expenses.first().title, 'Expense 1')
        self.assertEquals(response.status_code, 200)

    def test_post_create_POST(self):
        response = self.client.post(self.add_post_url, {
            'name':'MyProject2',
            'budget': 7500,
            'categoriesString': 'software,design'
        })

        # check that MyProject2 object created and its data entered succssesfully
        project2_obj = Project.objects.get(id=2)
        print(project2_obj.name)
        self.assertEquals(project2_obj.name, 'MyProject2') 
        

        first_category = Category.objects.get(id=1)
        self.assertEquals(first_category.name, 'software')
        self.assertEquals(first_category.project, project2_obj)


        second_category = Category.objects.get(id=2)
        self.assertEquals(second_category.name, 'design')
        self.assertEquals(second_category.project, project2_obj)


# Provide a docstring for the entire test class
"""
This test class is used to test the views of the 'budget' Django application. It includes tests for the project list view, project detail view, and adding a new expense to a project.
"""

# Run these tests by using Django's test runner (e.g., 'python manage.py test budget.tests')

"""
In the context of running tests in Django, your project code is executed first,
 and then the Django test runner is invoked to manage the testing process. Here's how the sequence of events typically occurs:

1. **Your Project Code**: Your Django project code, including your application code, models, views, and tests, 
forms the foundation of your application.

2. **Django Test Runner Invocation**: When you initiate the process to run tests, 
typically using a command like `python manage.py test`, the Django test runner is invoked.

3. **Test Discovery**: The Django test runner begins by discovering and collecting your test cases and test methods
 based on the naming conventions you've followed in your project's test files.

"""